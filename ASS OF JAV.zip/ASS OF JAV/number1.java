/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question1;

/**
 *
 * @author Clementine
 */
import java.util.Scanner;
public class number1 {
     public static void main(String[] args) {
         Scanner n=new Scanner(System.in);
        System.out.println("enter a number:");
        int number=n.nextInt();
        if(number%2==0){
            System.out.print(number+"is even");}
        else{
            System.out.print(number+"is add");
        }
     n.close();
    }
    
}
