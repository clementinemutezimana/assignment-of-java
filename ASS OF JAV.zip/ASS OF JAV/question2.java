/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Clementine
 */
import java.util.Scanner;
public class question2 {
      public static void main(String[] args) {
        Scanner n = new Scanner(System.in);
        System.out.print("Enter a grade (A, B, C, D, F): ");
        char grade = n.next().charAt(0);
       switch (grade) {
            case 'A':
                System.out.println("Excellent job!");
                break;
            case 'B':
                System.out.println("Great work!");
                break;
            case 'C':
                System.out.println("Good effort!");
                break;
            case 'D':
                System.out.println("Keep trying!");
                break;
            case 'F':
                System.out.println("Better luck next time!");
                break;
            default:
                System.out.println("Invalid grade entered.");
                break;
        }

        n.close();
    }
}
 

