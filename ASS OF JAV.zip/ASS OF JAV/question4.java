/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Clementine
 */
import java .util.Scanner;
public class question4 {
      public static void main(String[] args) {
         Scanner n = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        int num1 = n.nextInt();
        System.out.print("Enter the second number: ");
        int num2 = n.nextInt();
        System.out.print("Enter the third number: ");
        int num3 = n.nextInt();

        if (num1 >= num2 && num1 >= num3) {
            System.out.println(num1 + " is the largest.");
        } else if (num2 >= num1 && num2 >= num3) {
            System.out.println(num2 + " is the largest.");
        } else {
            System.out.println(num3 + " is the largest.");
        }

        n.close();
    
      }}
